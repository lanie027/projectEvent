﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementSystem.module
{
    interface interface_getuserrowdata
    {
        class_user GetUserRowData(string username);
    }
}
