﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanManagementSystem
{
    public partial class temp : Form
    {
        public temp()
        {
            InitializeComponent();
        }

        private void panel_dashboard_loanlist_createloanform_Paint(object sender, PaintEventArgs e)
        {

        }

        private void picturebox_dashboard_loanlist_collateralupload_Click(object sender, EventArgs e)
        {

        }
    }
}
