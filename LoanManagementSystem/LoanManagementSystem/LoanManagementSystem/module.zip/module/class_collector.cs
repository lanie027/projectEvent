﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementSystem.module
{
    internal class class_collector : class_user, interface_getuserrowdata
    {
        public class_user GetUserRowData(string username)
        {
            throw new NotImplementedException();
        }
    }
}
