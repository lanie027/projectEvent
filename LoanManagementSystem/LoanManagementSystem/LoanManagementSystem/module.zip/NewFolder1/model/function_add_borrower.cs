﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementSystem.controller
{
    internal class function_add_borrower
    {
        public function_add_borrower()
        {

        }
    }
}
