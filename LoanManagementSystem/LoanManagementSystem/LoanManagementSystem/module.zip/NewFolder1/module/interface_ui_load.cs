﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementSystem.module
{
    interface interface_ui_load
    {
        void load();
    }
}
