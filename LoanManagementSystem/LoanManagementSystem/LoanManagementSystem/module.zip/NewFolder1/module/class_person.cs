﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementSystem.module
{
    abstract class class_person
    {
        private int id;
        private string name;
        private int age;

        public void setId(int id) { }
        public void setName(string name) { }
        public void setAge(int age) { }
    }
}
